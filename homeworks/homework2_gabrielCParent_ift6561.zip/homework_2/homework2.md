
# IFT6561    Homework 2
# Gabriel C-Parent    C5912


## General comments


## Exercise 1


Please see Gumbel.java for the algorithm's implementation.


## Exercise 2


